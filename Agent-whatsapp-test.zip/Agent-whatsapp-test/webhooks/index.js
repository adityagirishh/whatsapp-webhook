require("dotenv").config(); // 👈 MUST be first

const express = require("express");

const app = express();

// ==============================
// VERIFY ENV LOAD
// ==============================
console.log("🧪 ENV CHECK");
console.log("PORT:", process.env.PORT);
console.log("MYTOKEN:", process.env.MYTOKEN ? "LOADED" : "MISSING");
console.log("TOKEN:", process.env.TOKEN ? "LOADED" : "MISSING");

// ==============================
// LOG ALL REQUESTS
// ==============================
app.use((req, res, next) => {
  console.log("🔥 HIT");
  console.log("METHOD:", req.method);
  console.log("URL:", req.url);
  next();
});

// ==============================
// ROUTES
// ==============================
app.get("/", (req, res) => {
  res.send("OK");
});

app.get("/webhook", (req, res) => {
  console.log("🔐 VERIFICATION HIT");
  res.send(req.query["hub.challenge"] || "OK");
});

app.post("/webhook", (req, res) => {
  console.log("✅ POST /webhook RECEIVED");
  res.sendStatus(200);
});

// ==============================
// START SERVER
// ==============================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 SERVER STARTED ON ${PORT}`);
});
