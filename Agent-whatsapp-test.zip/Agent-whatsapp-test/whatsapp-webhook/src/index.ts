import express from "express";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config({ path: ".env" });

console.log("🔥 SERVER FILE LOADED");

const app = express();
app.use(express.json());

app.use((req, _res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  if (req.method === 'POST') {
    console.log('Headers:', req.headers);
  }
  next();
});

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN!;
const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN!;
const PHONE_NUMBER_ID = "948451921685989";

/* Verification */
app.get("/webhook", (req, res) => {
  console.log("🔍 Webhook verification request:");
  console.log("Query params:", req.query);
  
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  console.log(`Mode: ${mode}, Token: ${token}, Challenge: ${challenge}`);
  console.log(`Expected token: ${VERIFY_TOKEN}`);

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    console.log("✅ Verification successful");
    return res.status(200).send(challenge);
  }
  console.log("❌ Verification failed");
  return res.sendStatus(403);
});

/* Messages */
app.post("/webhook", async (req, res) => {
  console.log("📨 POST /webhook received");
  console.log("Full body:", JSON.stringify(req.body, null, 2));
  
  const value = req.body.entry?.[0]?.changes?.[0]?.value;
  console.log("Extracted value:", value);
  
  const message = value?.messages?.[0];
  console.log("Message object:", message);

  if (!message) {
    console.log("❌ No message found");
    return res.sendStatus(200);
  }

  if (message.type !== "text") {
    console.log(`❌ Message type is ${message.type}, not text`);
    return res.sendStatus(200);
  }

  const from = message.from;
  const text = message.text.body?.toLowerCase();
  const messageId = message.id;

  if (!from || !messageId) {
    return res.sendStatus(200);
  }

  console.log("User said:", text);

  // Get phone number ID from the webhook payload
  const phoneNumberId = value?.metadata?.phone_number_id || PHONE_NUMBER_ID;
  console.log("📞 Using phone number ID:", phoneNumberId);

  // Respond to any text message (for testing)
  try {
    console.log("🚀 Attempting to send reply to:", from);
    
    await axios.post(
      `https://graph.facebook.com/v19.0/${phoneNumberId}/messages`,
      {
        messaging_product: "whatsapp",
        to: from,
        text: { body: `You said: ${text}` }
      },
      {
        headers: {
          Authorization: `Bearer ${WHATSAPP_TOKEN}`,
          "Content-Type": "application/json"
        }
      }
    );
    console.log("✅ Reply sent successfully");
  } catch (err: any) {
    console.error("❌ Send failed:", err.response?.data || err.message);
  }

  res.sendStatus(200);
});

/* Test endpoint */
app.get("/test", (req, res) => {
  console.log("🧪 Test endpoint hit");
  res.json({ 
    status: "OK", 
    timestamp: new Date().toISOString(),
    ngrok_url: "https://56199753cce1.ngrok-free.app"
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Webhook server running on port ${PORT}`);
});
